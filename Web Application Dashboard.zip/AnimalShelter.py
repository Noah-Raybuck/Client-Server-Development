from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections. 
        self.client = MongoClient('mongodb://%s:%s@localhost:42897' % (username, password))
        self.database = self.client['AAC']

# Complete this create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            self.database.animals.insert_one(data)  # data should be dictionary 
        else:
            raise Exception("Nothing to save, because data parameter is empty")

# Create method to implement the R in CRUD. 
    def read(self, info=None):
        if info is not None:
            data = self.database.animals.find(info, {"_id":False})
        else:
            data = self.database.animals.find( {} , {"_id":False})
            raise Exception("Cannot find a matching piece of data")
            
        return data
    
# Update Method
    def update(self, old_data, new_data):
        if old_data is not None:
            self.database.animals.update_one(old_data, new_data)
        else:
            raise Exceptions("Missing query to update")
    
#Delete Method
    def delete(self, data):
        if data is not None:
            self.database.animals.delete_one(data)  # data should be dictionary 
        else:
            raise Exception("Nothing to delete, because data parameter is empty")
        
    